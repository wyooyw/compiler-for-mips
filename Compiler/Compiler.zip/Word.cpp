﻿#include "Word.h"
using namespace std;
#define MAX_WORD_LEN 200

char* Word::getWord() {
	return word;
}
void Word::setWord(char* str) {
	strcpy(word, str);
}
WORD_TYPE Word::getType() {
	return type;
}
void Word::setType(const WORD_TYPE t) {
	type = t;
}
Error Word::getError() {
	return error;
}
void Word::setError(Error err) {
	error = err;
}