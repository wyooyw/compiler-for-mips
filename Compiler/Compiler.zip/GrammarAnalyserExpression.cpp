﻿#include "GrammarAnalyser.h"
using namespace std;

/*
	GrammarAnalyserExpression.cpp
	包含<表达式>、<因子>、<项>
*/

//表达式
void GrammarAnalyser::g_expression() {
	
	if (word.getType() == PLUS || word.getType() == MINU) {
		getWord();
	}
	g_term();

	while (true) {
		if (tryWord(1) &&
			(tryword.getType() == PLUS || tryword.getType() == MINU)) {
			getWord();
			g_plus();

			getWord();
			g_term();
		}
		else {
			break;
		}
	}
	fout << "<表达式>" << endl;
}

//项
void GrammarAnalyser::g_term() {
	g_factor();

	while (true) {
		if (tryWord(1) &&
			(tryword.getType() == MULT || tryword.getType() == DIV)) {
			getWord();
			g_mul();

			getWord();
			g_factor();
		}
		else {
			break;
		}
	}
	fout << "<项>" << endl;
}

//因子
void GrammarAnalyser::g_factor() {
	
	if (word.getType() == LPARENT) {
		getWord();
		g_expression();

		getWord();
		if (word.getType() != RPARENT) goError();
	}
	else if (word.getType() == CHARCON) {

	}
	else if (word.getType() == PLUS || word.getType() == MINU || word.getType() == INTCON) {
		
		g_int();
	}
	else if (word.getType() == IDENFR && 
		tryWord(1) && tryword.getType() == LPARENT) {//函数
		
		g_func_ret_call();
	}
	else if (word.getType() == IDENFR) {
		tryWord(1);
		if (tryword.getType() == LBRACK) {
			getWord();
			getWord();
			g_expression();

			getWord();
			if (word.getType() != RBRACK) goError();
		}

		tryWord(1);
		if (tryword.getType() == LBRACK) {
			getWord();
			getWord();
			g_expression();

			getWord();
			if (word.getType() != RBRACK) goError();
		}

	}
	

	fout << "<因子>" << endl;
}