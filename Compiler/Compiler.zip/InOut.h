﻿#include <fstream>
#include <string>
#ifndef IN_OUT_H
#define IN_OUT_H
using namespace std;
const string OUT_PATH = "./output.txt";
extern ofstream fout;

#endif