﻿#include <map>
#include <string>
#include <iostream>
#include <fstream>

#include "Error.h"
#include "Word.h"
#include "InOut.h"

#ifndef LEXICAL_ANALYSER_H
#define LEXICAL_ANALYSER_H

class LexicalAnalyser {
public:
	LexicalAnalyser();
	bool readWord(Word& word);
	bool tryReadWord(Word& word, int l);
	//Word& getTryReadWord(int i);
private:
	char* buffer;
	long buffer_size;
	char* buf_ptr;
	Word tryWord[10];
	map<string, WORD_TYPE> keyword_table;
	map<char, WORD_TYPE> sign_table;
	void readfile();
	void init();
	void initKeywordTable();
	void initSignTable();
	void passSpace();
	bool isDigital(char c);
	bool isLetter(char c);
	bool nextWord(Word& word);
};
#endif