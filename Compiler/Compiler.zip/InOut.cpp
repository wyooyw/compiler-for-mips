﻿#include "InOut.h";
using namespace std;
ofstream fout(OUT_PATH);