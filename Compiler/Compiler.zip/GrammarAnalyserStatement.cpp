﻿#include "GrammarAnalyser.h"
using namespace std;

/*
	GrammarAnalyserStatement.cpp
	包含
*/

//语句
void GrammarAnalyser::g_statement() {
	if (word.getType() == WHILETK || word.getType() == FORTK) {
		g_loop_statement();
	}
	else if (word.getType() == IFTK) {
		g_cond_statement();
	}
	else if (word.getType() == PRINTFTK) {
		//读语句
		g_printf_statement();

		getWord();
		if (word.getType() != SEMICN) goError();
	}
	else if (word.getType() == SCANFTK) {
		//写语句
		g_scanf_statement();

		getWord();
		if (word.getType() != SEMICN) goError();
	}
	else if (word.getType() == SWITCHTK) {
		//情况语句
		g_switch_statement();
	}
	else if (word.getType() == SEMICN) {
		//空语句
		//getWord();
	}
	else if (word.getType() == RETURNTK) {
		//返回语句
		g_return_statement();

		getWord();
		if (word.getType() != SEMICN) goError();
	}
	else if (word.getType() == LBRACE) {
		//getWord();
		g_statement_list();

		getWord();
		if (word.getType() != RBRACE) goError();

	}
	else if (word.getType() == IDENFR) {
		
		//有返回值函数语句、无返回值函数语句 或 赋值语句
		if (tryWord(1) && tryword.getType()==LPARENT) {
			if (hasReturnValue(word.getWord())) {
				g_func_ret_call();
			}
			else {
				g_func_no_ret_call();
			}

			getWord();
			if (word.getType() != SEMICN) goError();
		}
		else {
			g_assign_statement();

			getWord();
			if (word.getType() != SEMICN) goError();
		}
	}

	fout << "<语句>" << endl;
}

//赋值语句
void GrammarAnalyser::g_assign_statement() {
	if (word.getType() != IDENFR) goError();

	getWord();
	if (word.getType() == LBRACK) {
		getWord();
		g_expression();
		
		getWord();
		if (word.getType() != RBRACK) goError();

		getWord();
		if (word.getType() == LBRACK) {
			getWord();
			g_expression();

			getWord();
			if (word.getType() != RBRACK) goError();

			getWord();
		}
	}
	if (word.getType() != ASSIGN) goError();
	
	getWord();
	g_expression();

	fout << "<赋值语句>" << endl;
}
//条件
void GrammarAnalyser::g_cond() {
	g_expression();

	getWord();
	g_relation();

	getWord();
	g_expression();

	fout << "<条件>" << endl;
}

//条件语句
void GrammarAnalyser::g_cond_statement() {
	if (word.getType() != IFTK) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	getWord();
	g_cond();

	getWord();
	if (word.getType() != RPARENT) goError();

	getWord();
	g_statement();

	if (tryWord(1) && tryword.getType() == ELSETK) {
		getWord();
		getWord();
		g_statement();
	}

	fout << "<条件语句>" << endl;
}

//步长
void GrammarAnalyser::g_loop_step() {
	g_unsigned_int();
	fout << "<步长>" << endl;
}

//循环语句
void GrammarAnalyser::g_loop_statement() {
	if (word.getType() == WHILETK) {
		getWord();
		if (word.getType() != LPARENT) goError();

		getWord();
		g_cond();

		getWord();
		if (word.getType() != RPARENT) goError();

		getWord();
		g_statement();
	}
	else if (word.getType() == FORTK) {
		getWord();
		if (word.getType() != LPARENT) goError();

		getWord();
		if (word.getType() != IDENFR) goError();

		getWord();
		if (word.getType() != ASSIGN) goError();

		getWord();
		g_expression();

		getWord();
		if (word.getType() != SEMICN) goError();

		getWord();
		g_cond();

		getWord();
		if (word.getType() != SEMICN) goError();

		getWord();
		if (word.getType() != IDENFR) goError();

		getWord();
		if (word.getType() != ASSIGN) goError();

		getWord();
		if (word.getType() != IDENFR) goError();

		getWord();
		if (word.getType() != PLUS && word.getType() != MINU) goError();
	
		getWord();
		g_loop_step();

		getWord();
		if (word.getType() != RPARENT) goError();

		getWord();
		g_statement();
	}
	else {
		goError();
	}

	fout << "<循环语句>" << endl;
}

//语句列
void GrammarAnalyser::g_statement_list(){
	tryWord(1);
	if (tryword.getType() != RBRACE) {
		getWord();

		while (true) {
			g_statement();
			tryWord(1);
			if (tryword.getType() == RBRACE) {
				break;
			}
			else {
				getWord();
			}
		}
	}
	fout << "<语句列>" << endl;
}

//读语句
void GrammarAnalyser::g_scanf_statement() {
	if (word.getType() != SCANFTK) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	getWord();
	if (word.getType() != IDENFR) goError();

	getWord();
	if (word.getType() != RPARENT) goError();

	fout << "<读语句>" << endl;
}

//写语句
void GrammarAnalyser::g_printf_statement() {
	if (word.getType() != PRINTFTK) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	getWord();
	if (word.getType() == STRCON) {
		g_string();

		tryWord(1);
		if (tryword.getType() == COMMA) {
			getWord();

			getWord();
			g_expression();
		}
	}
	else {
		g_expression();
	}

	getWord();
	if (word.getType() != RPARENT) goError();

	fout << "<写语句>" << endl;
}

//返回语句
void GrammarAnalyser::g_return_statement() {
	if (word.getType() != RETURNTK) goError();

	tryWord(1);
	if (tryword.getType() == LPARENT) {
		getWord();

		getWord();
		g_expression();

		getWord();
		if (word.getType() != RPARENT) goError();
	}

	fout << "<返回语句>" << endl;
}

//情况语句
void GrammarAnalyser::g_switch_statement() {
	if (word.getType() != SWITCHTK) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	getWord();
	g_expression();

	getWord();
	if (word.getType() != RPARENT) goError();

	getWord();
	if (word.getType() != LBRACE) goError();

	getWord();
	g_switch_table();

	getWord();
	g_default();

	getWord();
	if (word.getType() != RBRACE) goError();

	fout << "<情况语句>" << endl;
}

//情况表
void GrammarAnalyser::g_switch_table() {
	g_switch_sub_statement();

	while (true) {
		tryWord(1);
		if (tryword.getType() != CASETK) {
			break;
		}

		getWord();
		g_switch_sub_statement();
	}

	fout << "<情况表>" << endl;
}

//情况子语句
void GrammarAnalyser::g_switch_sub_statement() {
	if (word.getType() != CASETK) goError();

	getWord();
	g_const();

	getWord();
	if (word.getType() != COLON) goError();

	getWord();
	g_statement();

	fout << "<情况子语句>" << endl;
}

//缺省
void GrammarAnalyser::g_default() {
	if (word.getType() != DEFAULTTK) goError();

	getWord();
	if (word.getType() != COLON) goError();

	getWord();
	g_statement();

	fout << "<缺省>" << endl;
}

//值参数表
void GrammarAnalyser::g_value_table() {
	tryWord(1);
	if (tryword.getType() != RPARENT) {
		getWord();
		g_expression();

		while (true) {
			tryWord(1);
			if (tryword.getType() != COMMA) {
				break;
			}
			getWord();

			getWord();
			g_expression();
		}
	}

	fout << "<值参数表>" << endl;
}

//有返回值函数调用语句
void GrammarAnalyser::g_func_ret_call() {
	
	if (word.getType() != IDENFR) goError();
	
	if (!hasReturnValue(word.getWord())) goError();
	
	getWord();
	if (word.getType() != LPARENT) goError();

	g_value_table();

	getWord();
	if (word.getType() != RPARENT) goError();

	fout << "<有返回值函数调用语句>" << endl;
}

//无返回值函数调用
void GrammarAnalyser::g_func_no_ret_call() {
	if (word.getType() != IDENFR) goError();

	if (hasReturnValue(word.getWord())) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	g_value_table();

	getWord();
	if (word.getType() != RPARENT) goError();

	fout << "<无返回值函数调用语句>" << endl;
}