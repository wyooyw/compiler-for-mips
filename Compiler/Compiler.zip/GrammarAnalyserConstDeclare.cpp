﻿#include "GrammarAnalyser.h"
using namespace std;

/*
	GrammarAnalyserConstDeclare.cpp
	包含<常量说明>、<常量定义>
*/

//常量说明
void GrammarAnalyser::g_const_declare() {
	if (word.getType() == CONSTTK) {
		getWord();
		g_const_def();

		getWord();
		if (word.getType() != SEMICN) goError();

		while (true) {
			if (tryWord(1) && tryword.getType() == CONSTTK) {
				getWord();

				getWord();
				g_const_def();

				getWord();
				if (word.getType() != SEMICN) goError();

			}
			else {
				fout << "<常量说明>" << endl;
				return;
			}


		}
	}
	else {
		fout << "a" << endl;
		goError();
	}
}

//常量定义
void GrammarAnalyser::g_const_def() {
	if (word.getType() == INTTK) {
		getWord();
		if (word.getType() != IDENFR)  goError();

		getWord();
		if (word.getType() != ASSIGN) goError();

		getWord();
		g_int();

		while (true) {

			if (tryWord(1) && tryword.getType() == COMMA) {
				getWord();

				getWord();
				if (word.getType() != IDENFR) goError();

				getWord();
				if (word.getType() != ASSIGN) goError();

				getWord();
				g_int();
			}
			else {
				fout << "<常量定义>" << endl;
				return;
			}
		}
	}
	else if (word.getType() == CHARTK) {
		getWord();
		if (word.getType() != IDENFR) goError();

		getWord();
		if (word.getType() != ASSIGN) goError();

		getWord();
		if (word.getType() != CHARCON) goError();

		while (true) {
			if (tryWord(1) && tryword.getType() == COMMA) {
				getWord();

				getWord();
				if (word.getType() != IDENFR) goError();

				getWord();
				if (word.getType() != ASSIGN) goError();

				getWord();
				if (word.getType() != CHARCON) goError();

			}
			else {
				fout << "<常量定义>" << endl;
				return;
			}
		}
	}
	else {
		goError();
	}
	getWord();
}

