﻿#include "GrammarAnalyser.h"
using namespace std;

/*
	GrammarAnalyserFunction.cpp
	包含<有返回值函数定义>、<无返回值函数定义>、<参数表>
*/

//参数表
void GrammarAnalyser::g_para_table() {
	tryWord(1);
	if (tryword.getType() != RPARENT) {
		int a;
		getWord();
		g_type_iden(a);

		getWord();
		if (word.getType() != IDENFR) goError();

		while (true) {
			tryWord(1);
			if (tryword.getType() == RPARENT) {
				break;
			}

			getWord();
			if (word.getType() != COMMA) goError();

			getWord();
			g_type_iden(a);

			getWord();
			if (word.getType() != IDENFR) goError();
		}
	}

	fout << "<参数表>" << endl;

}

//有返回值函数定义
void GrammarAnalyser::g_func_ret_def() {
	g_declare_head(true);

	getWord();
	if (word.getType() != LPARENT) goError();

	g_para_table();

	getWord();
	if (word.getType() != RPARENT) goError();

	getWord();
	if (word.getType() != LBRACE) goError();

	g_combine_statement();

	getWord();
	if (word.getType() != RBRACE) goError();

	fout << "<有返回值函数定义>" << endl;
}

//无返回值函数定义
void GrammarAnalyser::g_func_no_ret_def() {
	if (word.getType() != VOIDTK) goError();

	getWord();
	if (word.getType() != IDENFR) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	g_para_table();

	getWord();
	if (word.getType() != RPARENT) goError();

	getWord();
	if (word.getType() != LBRACE) goError();

	g_combine_statement();

	getWord();
	if (word.getType() != RBRACE) goError();

	fout << "<无返回值函数定义>" << endl;
}

//主函数
void GrammarAnalyser::g_main() {
	if (word.getType() != VOIDTK) goError();

	getWord();
	if (word.getType() != MAINTK) goError();

	getWord();
	if (word.getType() != LPARENT) goError();

	getWord();
	if (word.getType() != RPARENT) goError();

	getWord();
	if (word.getType() != LBRACE) goError();

	g_combine_statement();

	getWord();
	if (word.getType() != RBRACE) goError();

	fout << "<主函数>" << endl;
}

//复合语句
void GrammarAnalyser::g_combine_statement() {
	tryWord(1);
	if (tryword.getType() == CONSTTK) {
		getWord();
		g_const_declare();
		
		tryWord(1);
		if (tryword.getType() == CHARTK || tryword.getType() == INTTK) {
			getWord();
			g_var_declare();
			tryWord(1);
		}
	}else if (tryword.getType() == CHARTK || tryword.getType() == INTTK) {
		
		getWord();
		g_var_declare();
		tryWord(1);
	}
	g_statement_list();
	
		
	fout << "<复合语句>" << endl;
}