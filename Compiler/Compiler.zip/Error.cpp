﻿#include "Error.h"
	bool Error::isError() {
		return error;
	}
	void Error::setError(bool e) {
		error = e;
	}
	int Error::getRow() {
		return row;
	}
	void Error::setRow(int r) {
		row = r;
	}
	int Error::getCol() {
		return col;
	}
	void Error::setCol(int c) {
		col = c;
	}