﻿#include "LexicalAnalyser.h"
#include "GrammarAnalyser.h"
#include "InOut.h"

#define _CRT_SECURE_NO_WARNINGS
using namespace std;
const string IN_PATH = "./testfile.txt";

int main() {
	LexicalAnalyser lexicalAnalyser;
	GrammarAnalyser grammarAnalyser(lexicalAnalyser);
	Word word;

	/*while (lexicalAnalyser.readWord(word)) {
		Error error = word.getError();
		if (error.isError()) {
			out << "Wrong at row " << error.getRow() << " col " << error.getCol() << endl;
		}
		else {
			out << WORD_TYPE_STR[word.getType()] << " " << word.getWord() << endl;
		}
	}*/
	grammarAnalyser.begin();
	fout.close();
	return 0;
}