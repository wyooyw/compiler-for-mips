﻿#include "GrammarAnalyser.h"
using namespace std;

/*
	GrammarAnalyserVarDeclare.cpp
	包含<变量说明>、<变量定义>、<变量定义及初始化>、<变量定义无初始化>
	<二维数组初始化>、<一维数组初始化>
*/

//变量说明
void GrammarAnalyser::g_var_declare() {
	g_var_def();

	getWord();
	if (word.getType() != SEMICN) goError();
	while (true) {
		if (!tryWord(1)) {
			break;
		}
		if (tryWord(1) && tryword.getType() != CHARTK
						&& tryword.getType() != INTTK) {
			break;
		}
		if (tryWord(3) && tryword.getType() == LPARENT) {
			break;
		}
		getWord();
		g_var_def();

		getWord();
		if (word.getType() != SEMICN) goError();
	}
	fout << "<变量说明>" << endl;
}

//变量定义
void GrammarAnalyser::g_var_def() {
	int type, d = 0, n = 0, m = 0;
	g_type_iden(type);

	getWord();
	if (word.getType() != IDENFR) goError();

	//第一个中括号
	if (tryWord(1) && tryword.getType() == LBRACK) {
		getWord();

		d = 1;

		getWord();
		g_unsigned_int(n);//上次写到这里

		getWord();
		if (word.getType() != RBRACK) goError();


		//第二个中括号
		if (tryWord(1) && tryword.getType() == LBRACK) {
			getWord();

			d = 2;

			getWord();
			g_unsigned_int(m);

			getWord();
			if (word.getType() != RBRACK) goError();


		}

	}

	tryWord(1);
	if (tryword.getType() == ASSIGN) {
		getWord();
		g_var_def_init(type, d, n, m);
	}
	else if (tryword.getType() == COMMA || tryword.getType() == SEMICN) {
		g_var_def_no_init();
	}

	fout << "<变量定义>" << endl;
}

//变量定义无初始化
void GrammarAnalyser::g_var_def_no_init() {

	while (true) {
		if (tryWord(1) && tryword.getType() == COMMA) {
			getWord();

			getWord();
			if (word.getType() != IDENFR) goError();

			//第一个中括号
			if (tryWord(1) && tryword.getType() == LBRACK) {
				getWord();

				getWord();
				g_unsigned_int();

				getWord();
				if (word.getType() != RBRACK) goError();

				//第二个中括号
				if (tryWord(1) && tryword.getType() == LBRACK) {
					getWord();

					getWord();
					g_unsigned_int();

					getWord();
					if (word.getType() != RBRACK) goError();
				}
			}
		}
		else {
			fout << "<变量定义无初始化>" << endl;
			break;
		}
	}
}

//变量定义及初始化
void GrammarAnalyser::g_var_def_init(int type, int d, int n, int m) {

	if (d == 0) {
		getWord();
		g_const();
	}
	else if (d == 1) {
		getWord();
		g_one_d_arr(type, n);
	}
	else {
		getWord();
		g_two_d_arr(type, n, m);
	}


	fout << "<变量定义及初始化>" << endl;
}

//二维数组初始化
void GrammarAnalyser::g_two_d_arr(int type, int n, int m) {
	if (word.getType() != LBRACE) goError();
	getWord();
	g_one_d_arr(type, m);

	for (int i = 1; i < n; i++) {
		getWord();
		if (word.getType() != COMMA) goError();
		getWord();
		g_one_d_arr(type, m);
	}
	getWord();
	if (word.getType() != RBRACE) goError();
}

//一维数组初始化
void GrammarAnalyser::g_one_d_arr(int type, int n) {
	if (word.getType() != LBRACE) goError();

	getWord();
	g_const();
	for (int i = 1; i < n; i++) {
		getWord();
		if (word.getType() != COMMA) goError();
		getWord();
		g_const();
	}
	getWord();
	if (word.getType() != RBRACE) goError();
}