﻿#ifndef ERROR_H

#define ERROR_H

class Error {
public:
	bool isError();
	void setError(bool e);
	int getRow();
	void setRow(int r);
	int getCol();
	void setCol(int c);
private:
	bool error = false;
	int row;
	int col;
};

#endif